
                 This is a free model downloaded from

                 http://gfx-3d-model.blogspot.com doesnt contain any copyrights,

                 you can use it for you projects without any restrictions.